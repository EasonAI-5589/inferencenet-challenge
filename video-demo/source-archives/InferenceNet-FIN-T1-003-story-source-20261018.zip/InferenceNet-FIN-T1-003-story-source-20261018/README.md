# FIN-T1-003 · finance story source

After extracting, enter this directory (the one containing story.html).

## Preview

```sh
python3 -m http.server 4198 --bind 127.0.0.1
```

Open http://127.0.0.1:4198/story.html. Reuse or coordinate any existing service
on that port before starting another one.

Edit story.html for layout, story.js for animation and fixed captions, and
data/fin-story.json for the existing story data. The curation file records
editorial choices; changing it alone does not update the page's JSON snapshot.

## Export

```sh
python3 render.py --page story.html --data data/fin-story.json --name fin-story
```

Use --page story.html explicitly. The default index.html is not part of this
package. Outputs are out/fin-story.mp4, its poster and contact sheet.
Set FFMPEG or NODE to override executables; otherwise they are found on PATH.
The current video has 2344 frames at 30 fps (78.133 seconds).

## Requirements and scope

This is the editable animation source, with its recorded data snapshot,
fonts, font licence and export scripts. The finished MP4 is supplied separately.
Preview requires Python 3 and a browser; no API key or private data is needed.
Space pauses/resumes; arrow keys seek. Add ?t=30&pause to hold at 30 seconds.

Export requires Python 3, Node.js 22+, Chrome/Chromium and ffmpeg.
Set CHROME to your browser executable if it is not at the standard macOS path.
Capture uses a separate temporary browser profile. A Chinese system font
(such as Noto Sans CJK) is needed for Chinese text.

The data represents a historical run, with a compressed timeline. This source
package does not contain private raw task files, model credentials or tools
for rebuilding the original research run.

Verify the extracted files: `shasum -a 256 -c SHA256SUMS`.
